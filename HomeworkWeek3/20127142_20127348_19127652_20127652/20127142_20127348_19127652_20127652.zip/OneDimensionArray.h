#ifndef ONE_DIMENSION_ARRAY_H
#define ONE_DIMENSION_ARRAY_H
#include <iostream>
using namespace std;

void InputArray_1D(int*& a, int& n);
void FreeArray(int*& a);
void OutputArray_1D(int* a, int n);

#endif
